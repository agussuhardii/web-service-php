
var serverDns = "http://localhost/";
//var serverDns = "http://192.168.1.4/";

//var barangClienObject = serverDns+"barang/middleware/barang.clien.json";
var barangClienObject = serverDns+"barang/middleware/barang.clien.php";

var getBarangObjectServices = serverDns+"barang/middleware/barang.controller.php";



