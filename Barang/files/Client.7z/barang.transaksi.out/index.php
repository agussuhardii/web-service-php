<?php
/**
 * Created by IntelliJ IDEA.
 * User: Agus Suhardi
 * Date: 6/22/2016
 * Time: 07:33
 */
header("Location: layout/");