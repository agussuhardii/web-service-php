<?php
/**
 * Created by IntelliJ IDEA.
 * User: Agus Suhardi
 * Date: 5/26/2016
 * Time: 00:20
 */
class dns extends PDO{

    protected $db = "mysql";
    protected $hostName = "localhost";
    
}

